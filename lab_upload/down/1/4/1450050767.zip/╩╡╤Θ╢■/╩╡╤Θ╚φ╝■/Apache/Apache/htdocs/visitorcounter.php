﻿<?php

$c_file="counter.txt"; //文件名赋值给变量

if(!file_exists($c_file)) //如果文件不存在的操作

{

$myfile=fopen($c_file,"w"); //创建文件

fwrite($myfile,"0"); //置入“0”

fclose($myfile); //关闭文件

}

$t_num=file($c_file); //把文件内容读入变量

echo "welcome !".'<br />';
$t_num[0] = $t_num[0] + 1;

//必做1: 在下面添加代码统计访客数量

//必做1结束

echo "you are the visitor of number ".$t_num[0]."! ".'<br />'.'<br />'.'<br />'.'<br />'; //显示文件内容

//必做2: 在下面空白处添加代码实现动态显示图片功能

//要求首次访问和非首次访问显示不同图片

//先准备两张图片保存在htdocs文件夹下，或者新建文件夹保存

if($t_num[0]!==1)
	

	echo "<img src = 1.jpg> ".'<br />'.'<br />'.'<br />'.'<br />';


    //在这里添加代码显示图片1，

else
	echo "<img src = 2.jpg>".'<br />'.'<br />'.'<br />'.'<br />';
    //在这里添加显示图片2

//必做2结束

$myfile=fopen($c_file,"w"); //打开文件

fwrite($myfile,$t_num[0]); //写入新内容

fclose($myfile); //关闭文件
echo "\n";
echo $showtime=date("Y-m-d H:i:s");
//选作：其他你想实现的功能，比如表单收集、日期显示等

//选作结束

?>
